Changelog
=========

v1.1.1
------
- Fix to using the new way to fetch persistent variables. It's back to the old way >_>.

v1.1.0
------
- Added the trading filter to allow trading widgets to be created. See block_stash for more details.

v1.0.1
------

- Prevent exception when the stash is disabled

v1.0.0
------

- Support for shortcode for drops.
